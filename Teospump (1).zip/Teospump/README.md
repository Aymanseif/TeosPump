# Teospump

Decentralized launchpad for $TEOS-based tokens on Solana.