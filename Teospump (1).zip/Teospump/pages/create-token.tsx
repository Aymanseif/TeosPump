export default function CreateToken() {
  return <h1>Create Your Token</h1>;
}