# WHITEPAPER

This document will outline the full tokenomics and technical vision.